
cp /home/ec2-user/SageMaker/aws_web_crawler_workshop/product_tagging/data/TaipeiSansTCBeta-Regular.ttf /home/ec2-user/anaconda3/envs/python3/lib/python3.10/site-packages/matplotlib/mpl-data/fonts/ttf/
chmod 777 /home/ec2-user/anaconda3/envs/python3/lib/python3.10/site-packages/matplotlib/mpl-data/fonts/ttf/TaipeiSansTCBeta-Regular.ttf
rm /home/ec2-user/.cache/matplotlib/*
